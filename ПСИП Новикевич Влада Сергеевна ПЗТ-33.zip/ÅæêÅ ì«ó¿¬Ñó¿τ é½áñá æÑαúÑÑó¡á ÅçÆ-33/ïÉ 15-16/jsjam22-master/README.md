Gamedev.js Jam 2022 - _RAW_
============================

Game jam entry by Jimbly and Benjaminsen - "Aaron's Quest IV: When Moses Was Away"

* Play here: [dashingstrike.com/LudumDare/JS22/](http://www.dashingstrike.com/LudumDare/JS22/)
* Using [Javascript libGlov/GLOV.js framework](https://github.com/Jimbly/glovjs)
