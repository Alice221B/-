<?php 

$S1 = 'ВАША ФАМИЛИЯ';
$S2 = 'ADRES';

echo 'Длина строки S2 ';
echo strlen($S2);

$S3 = $S1 . ', ' . $S2;
echo $S3;

echo strtolower($S2);

?>