<?php 

$p = 'Программа';
$b = 'работает';
$result = $p . ' ' . $b;
$result .= ' плохо';
echo $result;

?>