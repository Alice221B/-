<?php 

$n = 'ПЗТ-33 ';
$i = 0;
while ($i < 22):
    echo $n;
    $i++;
endwhile;

?>