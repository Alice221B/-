<?php 

function f($x, $y){
    $result = ((pow(cos($x) - sin($y), 3))/(sqrt(pow($x, 2) + 1))) + pow(log10($x * $y), 2);
    return $result;
}

echo f(2, 3);

?>