<?php 

$ar = array(1, -2, 3, -4);
$result = 1;

for($i = 0; $i <= 3; $i++){
    if ($ar[$i] < 0){
        $result *= $ar[$i];
    }
}

echo $result;
?>