<?php
header('Location: avtoris.php');
?>