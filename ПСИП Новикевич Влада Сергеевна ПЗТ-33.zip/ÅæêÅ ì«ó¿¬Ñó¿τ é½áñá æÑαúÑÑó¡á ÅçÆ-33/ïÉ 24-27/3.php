<?php 

$a = 'Новикевич';
$b = 'Танцую, рисую';

file_put_contents('fio.txt', $a.$b);

?>